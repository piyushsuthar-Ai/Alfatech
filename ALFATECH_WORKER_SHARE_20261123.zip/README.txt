﻿ALFATECH WORKER - INSTALLATION GUIDE

1. Extract this ZIP file.
2. Run ALFATECH_WORKER_SETUP.exe and follow the installer.
3. Open ALFATECH WORKER.
4. Enter the Main Server HTTPS URL and pairing code provided by the server owner.
5. Wait for administrator approval.
6. Start the Worker when approval is complete.

IMPORTANT:
- The Main Server must be online and reachable.
- The installer is currently unsigned. Review Windows security warnings carefully.
- Do not disable antivirus or Windows security protections.
